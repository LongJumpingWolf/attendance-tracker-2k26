"use client"

import { useState } from "react"
import { GoogleLogo } from "@phosphor-icons/react"
import type { CloudSync } from "@/hooks/use-cloud-sync"
import { inputClass, primaryButton, tintButton } from "./sheet"

const label = "text-[12px] font-medium uppercase tracking-wider text-mute mb-2 px-1"
const card = "rounded-2xl bg-secondary p-4"

const STATUS: Record<CloudSync["status"], { text: string; cls: string }> = {
  off: { text: "Off", cls: "bg-ink/[0.07] text-mute" },
  syncing: { text: "Syncing…", cls: "bg-ink/[0.07] text-mute" },
  synced: { text: "Up to date", cls: "bg-good/15 text-good" },
  offline: { text: "Offline", cls: "bg-ink/[0.07] text-mute" },
  "too-large": { text: "Not backed up", cls: "bg-bad/10 text-bad" },
  "needs-choice": { text: "Waiting for you", cls: "bg-warn/15 text-warn" },
  paused: { text: "Paused while the demo shows", cls: "bg-ink/[0.07] text-mute" },
}

/** Settings > Sync between browsers: sign in with Google and your data follows you */
export default function SyncPanel({ sync, onToast }: { sync: CloudSync; onToast: (message: string) => void }) {
  const [email, setEmail] = useState("")
  const [error, setError] = useState("")
  const [busy, setBusy] = useState(false)
  const [confirmOut, setConfirmOut] = useState(false)

  const signIn = async () => {
    setBusy(true)
    setError("")
    const problem = await sync.signIn(email)
    setBusy(false)
    if (problem) setError(problem)
  }

  if (sync.kind === "none") {
    return (
      <div className={card}>
        <p className="text-[15px] font-semibold">Sync isn’t set up yet</p>
        <p className="text-[13px] text-mute mt-1 leading-snug">
          It needs the Firebase keys in <span className="num">.env.local</span>, Google switched on as a sign-in method, and the updated Firestore
          rules. Until then this browser keeps its own data.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {sync.kind === "dev" && (
        <p className="rounded-2xl bg-warn/15 text-warn text-[13px] font-medium leading-snug px-4 py-3">
          Test mode: no Firebase keys yet, so there is no real Google sign-in. Any email works as a stand-in, and the synced data lives on this dev
          server, so your laptop and phone can sync through it while it is running.
        </p>
      )}

      {sync.switchPlan ? (
        <section>
          <h3 className={label}>This Google account is already set up</h3>
          <div className={card}>
            <p className="text-[15px] font-semibold leading-snug">Use it here, and reconnect your mates?</p>
            <p className="text-[13px] text-mute mt-1 leading-snug">
              Your Google account was first used on another device, so this device will switch to it. The{" "}
              {sync.switchPlan.carry.length === 1 ? "mate" : `${sync.switchPlan.carry.length} mates`} you connected here (
              {sync.switchPlan.carry.map((c) => c.name).join(", ")}) will be asked to connect with your account again. Their history with you is kept.
            </p>
            <div className="grid gap-2 mt-4">
              <button
                disabled={busy}
                onClick={async () => {
                  setBusy(true)
                  const problem = await sync.confirmSwitch()
                  setBusy(false)
                  if (problem) setError(problem)
                  else onToast("Signed in. Your mates have been asked to reconnect.")
                }}
                className={primaryButton}
              >
                {busy ? "Switching…" : "Switch and reconnect"}
              </button>
              <button disabled={busy} onClick={sync.cancelSwitch} className={tintButton}>
                Cancel
              </button>
            </div>
            {error && <p className="text-[13px] text-bad mt-2 leading-snug">{error}</p>}
          </div>
        </section>
      ) : sync.account ? (
        <>
          <section>
            <h3 className={label}>Account</h3>
            <div className={`${card} flex items-center gap-3`}>
              <span className="min-w-0 flex-1">
                <span className="block text-[16px] font-semibold leading-snug truncate">{sync.account.name}</span>
                <span className="block text-[13px] text-mute leading-snug truncate">{sync.account.email}</span>
                <span className="block text-[13px] text-mute leading-snug">
                  {sync.lastAt ? `Last synced ${new Date(sync.lastAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : "Not synced yet"}
                </span>
              </span>
              <span className={`text-[12px] font-semibold rounded-full px-2.5 py-1 ${STATUS[sync.status].cls}`}>
                {sync.status === "offline" && sync.pending ? "Saved here, will sync" : sync.status === "synced" && sync.realtime ? "Up to date · live" : STATUS[sync.status].text}
              </span>
            </div>
            {sync.status === "needs-choice" && sync.reconcile && (
              <div className={`${card} mt-2`} data-testid="reconcile-waiting">
                <p className="text-[15px] font-semibold leading-snug">Choose how to combine your data</p>
                <p className="text-[13px] text-mute mt-1 leading-snug">
                  This device and your account both have data. Nothing is synced until you choose, and nothing has been changed.
                </p>
                <button onClick={sync.reopenReconcile} className={`${primaryButton} mt-3`}>
                  Choose
                </button>
              </div>
            )}
            {sync.status === "too-large" && (
              <p className="text-[13px] text-bad font-medium mt-2 px-1 leading-snug">Cloud backup is too large. Your data is safe on this device.</p>
            )}
            <button
              onClick={async () => onToast((await sync.syncNow()) ? "Updated from your other browser" : "Everything is up to date")}
              className={`${tintButton} w-full mt-2`}
            >
              Sync now
            </button>
            <p className="text-[13px] text-mute mt-3 px-1 leading-snug">
              Sign in with this same account in any other browser and your subjects, marks and deadlines appear there. If both browsers changed things, the changes are combined, never one thrown away. A scanned QR code then marks
              your attendance whichever browser opens it.
            </p>
          </section>

          <section>
            {confirmOut ? (
              <div className={card}>
                <p className="text-[15px] font-semibold leading-snug">Sign out in this browser?</p>
                <p className="text-[13px] text-mute mt-1 leading-snug">Nothing is deleted. Your account’s copy and the data here both stay as they are.</p>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <button onClick={() => setConfirmOut(false)} className={tintButton}>
                    Stay signed in
                  </button>
                  <button
                    onClick={() => {
                      setConfirmOut(false)
                      void sync.signOut()
                    }}
                    className={`${tintButton} text-bad`}
                  >
                    Sign out
                  </button>
                </div>
              </div>
            ) : (
              <button onClick={() => setConfirmOut(true)} className="text-[14px] text-mute px-1">
                Sign out in this browser
              </button>
            )}
          </section>
        </>
      ) : (
        <section>
          <h3 className={label}>Use your data in any browser</h3>
          <div className={card}>
            <p className="text-[13px] text-mute leading-snug">
              Sign in once in each browser you use (Safari, the home-screen app, Chrome). Your subjects, marks and deadlines are saved to your account
              and appear everywhere you sign in.
            </p>

            {sync.kind === "dev" && (
              <input
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value)
                  setError("")
                }}
                placeholder="test@example.com"
                inputMode="email"
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                className={`${inputClass} mt-3`}
                aria-label="Test email"
              />
            )}

            <button disabled={busy} onClick={() => void signIn()} className={`${primaryButton} w-full mt-3 flex items-center justify-center gap-2`}>
              <GoogleLogo weight="bold" className="w-5 h-5" />
              {busy ? "Signing in…" : sync.kind === "dev" ? "Test sign-in" : "Sign in with Google"}
            </button>
            {error && <p className="text-[13px] text-bad mt-2 leading-snug">{error}</p>}
            <p className="text-[12px] text-mute mt-3 leading-snug">
              Google may refuse to sign in inside a scanner app’s built-in browser. If it does, open the page in Safari or Chrome.
            </p>
          </div>
        </section>
      )}
    </div>
  )
}
